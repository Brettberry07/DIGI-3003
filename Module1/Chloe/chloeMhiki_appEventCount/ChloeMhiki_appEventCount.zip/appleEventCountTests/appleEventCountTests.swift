//
//  appleEventCountTests.swift
//  appleEventCountTests
//
//  Created by Hunter, Chloe Mikhayla A. (Student) on 10/18/24.
//

import Testing
@testable import appleEventCount

struct appleEventCountTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
