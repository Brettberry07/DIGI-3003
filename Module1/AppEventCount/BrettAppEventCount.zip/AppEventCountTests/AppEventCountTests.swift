//
//  AppEventCountTests.swift
//  AppEventCountTests
//
//  Created by Berry, Brett A. (Student) on 10/17/24.
//

import Testing
@testable import AppEventCount

struct AppEventCountTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
