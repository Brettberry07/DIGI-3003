//
//  Meal.swift
//  MealTracker
//
//  Created by Berry, Brett A. (Student) on 10/24/24.
//

import Foundation

struct Meal{
    var name: String
    var food: [Food]
}
