//
//  Food.swift
//  MealTracker
//
//  Created by Berry, Brett A. (Student) on 10/24/24.
//

import Foundation

struct Food{
    var name: String
    var description: String
}
