//
//  MealTrackerTests.swift
//  MealTrackerTests
//
//  Created by Berry, Brett A. (Student) on 10/24/24.
//

import Testing
@testable import MealTracker

struct MealTrackerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
