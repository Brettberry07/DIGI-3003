//
//  Bill+Extras.swift
//  BillManager
//

import Foundation

extension Bill {
    var hasReminder: Bool {
        return (remindDate != nil)
    }
    
    
    
    var formattedDueDate: String {
        let dateString: String
        
        if let dueDate = self.dueDate {
            dateString = dueDate.formatted(date: .numeric, time: .omitted)
        } else {
            dateString = ""
        }
        
        return dateString
    }
    
}
