//
//  ToDoList2Tests.swift
//  ToDoList2Tests
//
//  Created by Berry, Brett A. (Student) on 11/3/24.
//

import Testing
@testable import ToDoList2

struct ToDoList2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
