//
//  ContestTests.swift
//  ContestTests
//
//  Created by Berry, Brett A. (Student) on 11/8/24.
//

import Testing
@testable import Contest

struct ContestTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
