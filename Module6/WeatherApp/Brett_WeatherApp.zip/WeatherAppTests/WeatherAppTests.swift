//
//  WeatherAppTests.swift
//  WeatherAppTests
//
//  Created by Berry, Brett A. (Student) on 12/1/24.
//

import Testing
@testable import WeatherApp

struct WeatherAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
