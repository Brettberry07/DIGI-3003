//
//  ResponseModels.swift
//  OrderApp
//
//  Created by Berry, Brett A. (Student) on 11/15/24.
//

import Foundation

struct MenuResponse: Codable {
    let menu: [MenuItem]
}

struct CategoriesResponse: Codable {
    let categories: [String]
}

struct OrderResponse: Codable {
    let prepTime: Int
    
    enum CodingKeys: String, CodingKey {
        case prepTime = "preperation_time"
    }
}
