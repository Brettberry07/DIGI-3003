//
//  OrderAppTests.swift
//  OrderAppTests
//
//  Created by Berry, Brett A. (Student) on 11/14/24.
//

import Testing
@testable import OrderApp

struct OrderAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
